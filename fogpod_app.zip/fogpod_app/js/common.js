(function($, owner) {
	var urls={'ip':['http://192.168.88.1','router.fogpod.com']};
	var port=54171;
	/**
	 * 路由ajax
	 * @param {Object} path api路径
	 * @param {Object} type 请求类型
	 * @param {Object} data 数据对象
	 * @param {Object} callback 回调函数
	 */
	mui.router_ajax=function(path,type,data,callback,errors){
		path=urls['ip'][0]+':'+port+path;
		mui.ajax(path,{
			data:data,
			dataType:'json',//服务器返回json格式数据
			type:type,//HTTP请求类型
			timeout:5000,//超时时间设置为10秒；
			beforeSend: function() {
				plus.nativeUI.showWaiting();
			},
			crossDomain:true,
			complete: function() {
				plus.nativeUI.closeWaiting();
			},
			success:function(data){
				callback(data);
			},
			error:function(xhr,type,errorThrown){
					//异常处理；
				errors(type);
			}
		});
	}
	mui.modul_ajax=function(path,type,data,callback,errors){
		path=urls['ip'][0]+':'+port+path;
		mui.ajax(path,{
			data:data,
			dataType:'json',//服务器返回json格式数据
			type:type,//HTTP请求类型
			timeout:20000,//超时时间设置为10秒；
			beforeSend: function() {
				plus.nativeUI.showWaiting("全力加载中....",{
					padding:"10px",
					loading:{display:"inline"}
				});
			},
			crossDomain:true,
			complete: function() {
				plus.nativeUI.closeWaiting();
			},
			success:function(data){
				callback(data);
			},
			error:function(xhr,type,errorThrown){
					//异常处理；
				errors(type);
			}
		});
	}
	mui.check_ajax=function(path,type,data,callback,errors){
		path=urls['ip'][0]+':'+port+path;
		mui.ajax(path,{
			data:data,
			dataType:'json',//服务器返回json格式数据
			type:type,//HTTP请求类型
			timeout:5000,
			crossDomain:true,
			success:function(data){
				callback(data);
			},
			error:function(xhr,type,errorThrown){
					//异常处理；
				errors(type);
			}
		});
	}
	mui.lang=function (lang){ 
		mui("[data-lang]").each(function(){
			for(var key in lang.ui){
				if(this.getAttribute('data-lang')==key){ 
					if(this.innerText.indexOf(":")>=0){
						this.innerText=lang.ui[key]+":";
					}else if(this.getAttribute("type")=="radio"){
						var sp=document.createElement('span');
						sp.innerText=lang.ui[key];
						mui.insertAfter(sp,this);
					}else{
						this.innerText=lang.ui[key];
					}
				} 
			}
		})
		mui("input[placeholder]").each(function(){
			for(var key in lang.ui){
				if(this.getAttribute('placeholder')==key){ 
					this.setAttribute('placeholder',lang.ui[key]);
				} 
			}
		})
	}
	mui.insertAfter=function(newElement, targetElement ){ // newElement是要追加的元素 targetElement 是指定元素的位置 
		var parent = targetElement.parentNode; // 找到指定元素的父节点 
		if( parent.lastChild == targetElement ){ // 判断指定元素的是否是节点中的最后一个位置 如果是的话就直接使用appendChild方法 
			parent.appendChild( newElement, targetElement ); 
		}else{ 
			parent.insertBefore( newElement, targetElement.nextSibling ); 
		}
	}
	/**
	 *  委托事件
	 * @param {Object} dom 这里的dom为绑定事件的元素，比如document.body
	 * @param {Object} event event为绑定的事件，比如click
	 * @param {Object} listeners listeners是待执行的事件对象
	 */ 
	mui.delegate=function(dom,event,listeners){
		//#这里的dom为绑定事件的元素，比如document.body #event为绑定的事件，比如click #listeners是待执行的事件对象 
		addEvent(dom, event, function (e) { 
			
		    //#这里获取事件e #获取点击的元素src 
		    var e = e || window.event,
		          src = e.target || e.srcElement,
		          action,   returnVal; 
		    // #模拟冒泡的方式，先是src，然后是src.parentNode，再然后是src.parentNode.parentNode #当前dom元素等于事件绑定的dom元素的时候，停止“冒泡” 
		    while (src && src !== dom) {  
		        //#循环获取dom元素的attr - action属性， 
		         
		        action = src.getAttribute('attr-action');  
		        //#如果当前dom元素存在attr - action属性，并且事件对象中有该属性值的函数，执行这个函数  #将事件e、当前dom元素、元素的属性attr - action值传给要执行的函数  
		        if (listeners[action]) {  
		            returnVal = listeners[action]({   
		                src: src,
		                   e: e,
		                   action: action  
		            });  
		            //#如果上面的函数执行之后返回false，停止继续“冒泡”  
		            if (returnVal === false) {   
		                break;  
		            }  
		        }  
		        //#获取当前dom元素的父元素节点  
		        src = src.parentNode; 
		    } 
		});
	}
	function addEvent(obj, type, handle) { 
		    if (!obj || !type || !handle) { 
		        return; 
		    } 
		    //#绑定事件到多个对象，递归调用 
		    if (obj instanceof Array) { 
		        for (var i = 0,l = obj.length; i < l; i++) {  
		        		addEvent(obj[i], type, handle); 
		        } 
		        return; 
		    } 
		    //#绑定多个事件，递归调用 
		    if (type instanceof Array) { 
		        for (var i = 0,l = type.length; i < l; i++) {  
		        		addEvent(obj, type[i], handle); 
		        } 
		        return; 
		    } 
		    //#下面这一大段用来记录当前页面一共绑定了多少个事件，以及事件的相关信息 #以及某个对象上面绑定的事件id
		    window.__allHandlers = window.__allHandlers || {}; window.__Hcounter = window.__Hcounter || 0; 
		    function setHandler(obj, type, handler, wrapper) { obj.__hids = obj.__hids || []; 
		        var hid = 'h' + ++window.__Hcounter; obj.__hids.push(hid); window.__allHandlers[hid] = {  type: type,
		              handler: handler,
		              wrapper: wrapper 
		        } 
		    }
		    // #这个里面的apply是为了修改绑定事件所执行函数中的this #这个在低版本的IE中才真正起作用 
		    function createDelegate(handle, context) { 
		        return function() {  
		            return handle.apply(context, arguments); 
		        }; 
		    }  
		    //#绑定事件，记录事件绑定信息 
		    if (window.addEventListener) { 
		        var wrapper = createDelegate(handle, obj); setHandler(obj, type, handle, wrapper); 
		        obj.addEventListener(type, wrapper, false); 
		    } 
		    else if (window.attachEvent) { 
		        var wrapper = createDelegate(handle, obj); setHandler(obj, type, handle, wrapper);
		         obj.attachEvent("on" + type, wrapper); 
		    } 
		    else { obj["on" + type] = handle; 
		    }
		};
		//输入验证器
		mui.InputValidators=function () {
		    this.validators = [];
		    this.strategies = {};
		
		    //this.from(validationStrategies);
		}
		
		//添加验证方法
		//参数:
		//  rule: 验证策略字符串
		//  element: 被验证的dom元素
		//  errMsg: 验证失败时显示的提示信息
		//  value: 被验证的值
		mui.InputValidators.prototype.addValidator = function (rule, element, errMsg, value) {
			
		    var that = this;
		    var ruleElements = rule.split(":");
		
		    this.validators.push(function () {
		        var strategy = ruleElements.shift();
		        var params = ruleElements;
		        params.unshift(value);
		        params.unshift(errMsg);
		        params.unshift(element);
		        return that.strategies[strategy].apply(that, params);
		    });
		};
		
		//添加验证策略函数
		//参数:
		//  name: 策略名称
		//  strategy: 策略函数
		mui.InputValidators.prototype.addValidationStrategy = function (name, strategy) {
		    this.strategies[name] = strategy;
		};
		
		//从策略对象导入验证策略函数
		//参数:
		//  strategies: 包含各种策略函数的对象
		mui.InputValidators.prototype.importStrategies = function (strategies) {
		    for (var strategyName in strategies) {
		        this.addValidationStrategy(strategyName, strategies[strategyName]);
		    }
		};
		
		//验证失败时，将相关的错误信息打包返回
		//参数:
		//  element: dom元素
		//   errMsg: 验证失败时的提示消息
		//    value: 被验证的值
		mui.InputValidators.prototype.buildInvalidObj = function (element, errMsg, value) {
		    return {
		        'value': value,
		        'element': element,
		        'errMsg': errMsg
		    };
		};
		
		//开始验证
		mui.InputValidators.prototype.check = function () {
		    for (var i = 0, validator; validator = this.validators[i++];) {
		        var result = validator();
		        if (result) {
		            return result;
		        }
		    }
		};
		
		//验证策略对象，包含默认的验证策略函数
		var validationStrategies = {
		    isNoEmpty: function (element, errMsg, value) {
		            if (value === '') {
		                return this.buildInvalidObj(element, errMsg, value);
		            }
		        },
		
		        minLength: function (element, errMsg, value, length) {
		            if (value.length < length) {
		                return this.buildInvalidObj(element, errMsg, value);
		            }
		        },
		
		        maxLength: function (element, errMsg, value, length) {
		            if (value.length > length) {
		                return this.buildInvalidObj(element, errMsg, value);
		            }
		        }
		};
}(mui, window.app = {}));