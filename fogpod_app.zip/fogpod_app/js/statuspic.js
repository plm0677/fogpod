(function($,owner){
	var urls={'ip':['http://192.168.88.1','router.fogpod.com']};
	var port=54171;
//	状态判断
	owner.statusOne=function(key,callback){
		key=key||"";
		callback=callback||$.noop;
		mui.check_ajax("/1/wan/wan_connect_status","get",{"key":key},function(data){
			var lOne=document.getElementById("lightOne1");
			if(data.status==0&&data.connected==1){
				lOne.style.background="#62CB31";
			}else{
				lOne.style.background="#c81623";
			}
		},
		function(type){
			return false;
		}
		)
	}
	owner.statusTwo=function(loginInfo,callback){
		loginInfo = loginInfo || {};
		loginInfo.account = loginInfo.account || '';
		loginInfo.password = loginInfo.password || '';
		callback=callback||$.noop;
		mui.check_ajax("/1/system/login","get",{'name':loginInfo.account,'pwd':loginInfo.password},function(data){
			var lTwo=document.getElementById("lightOne2");
			if(data.status==0){
				lTwo.style.background="#62CB31";
			}else{
				lTwo.style.background="#c81623";
			}
		},function(type){
			var lTwo=document.getElementById("lightOne2");
			lTwo.style.background="#c81623";
		})
	}
}(mui,window.statuspic={}));
